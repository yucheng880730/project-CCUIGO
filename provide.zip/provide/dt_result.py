import pydotplus 
with open("precition.dot", 'w') as file:
	file = tree.export_graphviz(pred, out_file=file) 
#export dot file
dot_data = tree.export_graphviz(pred, out_file=None,feature_names=traindata.columns)  
graph = pydotplus.graph_from_dot_data(dot_data)  
graph.write_pdf("DT.pdf") 
ydf = pd.DataFrame(df_original, columns = ['isAlive'])
final_get = [df,df_binary,ydf]
final_csv = pd.concat(final_get , axis=1) 
final_csv.to_csv("final2.csv")
