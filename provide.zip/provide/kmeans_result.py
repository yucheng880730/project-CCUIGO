#store the result in three lists, and compare the original doc type to see the precision
article_cluster = [[] for x in range(3)]
index_cluster = [[]for y in range(3)]
c1 = [0,0,0]
c2 = [0,0,0]
c3 = [0,0,0]
statistic = [c1,c2,c3]


for index in range(len(model.labels_) ):
	cluster = model.labels_[index]
	topic = df["mainTag"][index]
	# take the original type of document	
	if (topic == 73):
		content = str(index)+":Weather氣象"
		statistic[cluster][0] += 1
	elif (topic == 689):
		content = str(index)+":Politic政治"
		statistic[cluster][1] += 1
	elif (topic == 1504 ):
		content = str(index)+":Sport運動"
		statistic[cluster][2] += 1
	index_cluster[cluster].append(index)	
	article_cluster[cluster].append(content)	
	#add data in list

#display the result of cluster
print("分群結果")
for index in index_cluster:
	print(index)
#show data in list 
i = 1
print ("-------------------------------------------")
for cluster_list in article_cluster:
	print ("第",i,"群")
	i = i+1
	for item in cluster_list:
		print(item)
	print ("Weather:",statistic[i-2][0], "Politic",statistic[i-2][1], "Sport",statistic[i-2][2])
	print ("-------------------------------------------")